import base from "@reflexjs/preset-base"

export default {
  preset: base,

  colors: {
    primary: `#005ae0`,
  },
}
